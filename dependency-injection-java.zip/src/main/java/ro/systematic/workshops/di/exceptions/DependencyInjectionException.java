package ro.systematic.workshops.di.exceptions;

public class DependencyInjectionException extends Exception {
    public DependencyInjectionException(String message){
        super(message);
    }
}
