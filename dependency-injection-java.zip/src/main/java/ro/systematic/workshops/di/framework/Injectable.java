package ro.systematic.workshops.di.framework;

public interface Injectable {
}
