package ro.systematic.workshops.di.injectables;

public interface ReportService {
    void printReport(String title);
}
