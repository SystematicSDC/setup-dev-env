package ro.systematic.workshops.di.testdata;

import ro.systematic.workshops.di.framework.Injectable;

public interface MockedInjectable extends Injectable {
}
