package ro.systematic.workshops.di.testdata.impl;

import ro.systematic.workshops.di.testdata.SecondMockedInjectable;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SecondMockedInjectableImpl implements SecondMockedInjectable {
    private static final Logger logger = LoggerFactory.getLogger(SecondMockedInjectableImpl.class);
}
